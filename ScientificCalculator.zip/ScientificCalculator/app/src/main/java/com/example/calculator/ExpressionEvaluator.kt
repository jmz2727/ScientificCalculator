package com.example.calculator

import kotlin.math.PI
import kotlin.math.E
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Safe mathematical expression evaluator.
 *
 * Infix -> RPN via the shunting-yard algorithm.
 * NEVER uses eval(), ScriptEngine, reflection, or dynamic code execution.
 * All malformed input throws [IllegalArgumentException] / [ArithmeticException]
 * which the ViewModel converts into a typed, localized UI error.
 */
class ExpressionEvaluator(private val useDegrees: Boolean = true) {

    sealed interface Token {
        data class Num(val value: Double) : Token
        data class Op(val symbol: String, val prec: Int, val rightAssoc: Boolean = false) : Token
        data class Func(val name: String) : Token
        data class Postfix(val symbol: String) : Token
        data object LParen : Token
        data object RParen : Token
    }

    companion object {
        private const val MAX_EXPRESSION_LENGTH = 1_000
        private const val MAX_STACK_DEPTH = 512
        private val KNOWN_FUNCTIONS = setOf(
            "sin", "cos", "tan",
            "asin", "acos", "atan",
            "ln", "log", "sqrt", "abs", "exp"
        )
    }

    @Throws(IllegalArgumentException::class, ArithmeticException::class)
    fun evaluate(expression: String): Double {
        require(expression.isNotBlank()) { "Empty expression" }
        require(expression.length <= MAX_EXPRESSION_LENGTH) { "Expression too long" }
        val tokens = tokenize(expression)
        require(tokens.isNotEmpty()) { "No tokens" }
        val rpn = toRpn(tokens)
        require(rpn.isNotEmpty()) { "Empty RPN" }
        return evalRpn(rpn)
    }

    // ------------------------------------------------------------- Tokenizer

    private fun tokenize(expr: String): List<Token> {
        val raw = ArrayList<Token>(expr.length)
        var i = 0
        while (i < expr.length) {
            val c = expr[i]
            when {
                c.isWhitespace() -> i++

                c.isDigit() || c == '.' -> {
                    val start = i
                    var dotCount = 0
                    while (i < expr.length && (expr[i].isDigit() || expr[i] == '.')) {
                        if (expr[i] == '.') dotCount++
                        if (dotCount > 1) throw IllegalArgumentException("Malformed number")
                        i++
                    }
                    val numStr = expr.substring(start, i)
                    val value = numStr.toDoubleOrNull()
                        ?: throw IllegalArgumentException("Malformed number")
                    require(value.isFinite()) { "Number out of range" }
                    raw.add(Token.Num(value))
                }

                c.isLetter() -> {
                    val start = i
                    while (i < expr.length && expr[i].isLetter()) i++
                    val name = expr.substring(start, i).lowercase()
                    when (name) {
                        "pi" -> raw.add(Token.Num(PI))
                        "e"  -> raw.add(Token.Num(E))
                        in KNOWN_FUNCTIONS -> raw.add(Token.Func(name))
                        else -> throw IllegalArgumentException("Unknown identifier")
                    }
                }

                c == 'π' -> { raw.add(Token.Num(PI)); i++ }
                c == '√' -> { raw.add(Token.Func("sqrt")); i++ }

                c == '+' -> { raw.add(Token.Op("+", 1)); i++ }
                c == '-' -> { raw.add(Token.Op("-", 1)); i++ }
                c == '*' || c == '×' -> { raw.add(Token.Op("*", 2)); i++ }
                c == '/' || c == '÷' -> { raw.add(Token.Op("/", 2)); i++ }
                c == '^' -> { raw.add(Token.Op("^", 4, rightAssoc = true)); i++ }
                c == '%' -> { raw.add(Token.Postfix("%")); i++ }
                c == '!' -> { raw.add(Token.Postfix("!")); i++ }
                c == '(' -> { raw.add(Token.LParen); i++ }
                c == ')' -> { raw.add(Token.RParen); i++ }
                else -> throw IllegalArgumentException("Invalid character")
            }
        }

        // Implicit multiplication between adjacent value-like tokens.
        val result = ArrayList<Token>(raw.size + 4)
        for (j in raw.indices) {
            val cur = raw[j]
            result.add(cur)
            if (j < raw.size - 1) {
                val next = raw[j + 1]
                val curIsValue = cur is Token.Num || cur is Token.RParen || cur is Token.Postfix
                val nextIsValue = next is Token.Num || next is Token.LParen || next is Token.Func
                if (curIsValue && nextIsValue) result.add(Token.Op("*", 2))
            }
        }
        return result
    }

    // ------------------------------------------------------- Shunting-yard

    private fun toRpn(tokens: List<Token>): List<Token> {
        val output = ArrayList<Token>(tokens.size)
        val stack = ArrayDeque<Token>()
        var prev: Token? = null

        for (t in tokens) {
            when (t) {
                is Token.Num -> output.add(t)
                is Token.Func -> stack.addLast(t)
                is Token.Postfix -> output.add(t)

                is Token.Op -> {
                    val isUnary = (t.symbol == "-" || t.symbol == "+") &&
                            (prev == null || prev is Token.Op || prev is Token.LParen)
                    val op = if (isUnary) Token.Op("u${t.symbol}", 3, rightAssoc = true) else t

                    while (stack.isNotEmpty()) {
                        val top = stack.last()
                        if (top is Token.Op &&
                            (top.prec > op.prec || (top.prec == op.prec && !op.rightAssoc))
                        ) output.add(stack.removeLast())
                        else break
                    }
                    stack.addLast(op)
                }

                Token.LParen -> stack.addLast(t)

                Token.RParen -> {
                    while (stack.isNotEmpty() && stack.last() !is Token.LParen) {
                        output.add(stack.removeLast())
                    }
                    if (stack.isEmpty()) throw IllegalArgumentException("Mismatched parentheses")
                    stack.removeLast()
                    if (stack.isNotEmpty() && stack.last() is Token.Func) {
                        output.add(stack.removeLast())
                    }
                }
            }
            prev = t
        }
        while (stack.isNotEmpty()) {
            val top = stack.removeLast()
            if (top is Token.LParen) throw IllegalArgumentException("Mismatched parentheses")
            output.add(top)
        }
        return output
    }

    // ---------------------------------------------------------------- Evaluate

    private fun evalRpn(rpn: List<Token>): Double {
        val stack = ArrayDeque<Double>()

        fun pop(): Double = stack.removeLastOrNull()
            ?: throw IllegalArgumentException("Invalid expression")

        fun push(v: Double) {
            require(stack.size < MAX_STACK_DEPTH) { "Expression too complex" }
            stack.addLast(v)
        }

        for (t in rpn) {
            when (t) {
                is Token.Num -> push(t.value)

                is Token.Op -> {
                    if (t.symbol == "u-" || t.symbol == "u+") {
                        val a = pop()
                        push(if (t.symbol == "u-") -a else a)
                    } else {
                        val b = pop()
                        val a = pop()
                        val r = when (t.symbol) {
                            "+" -> a + b
                            "-" -> a - b
                            "*" -> a * b
                            "/" -> {
                                if (b == 0.0) throw ArithmeticException("Division by zero")
                                a / b
                            }
                            "^" -> {
                                val powered = a.pow(b)
                                if (powered.isNaN()) throw ArithmeticException("Undefined power")
                                powered
                            }
                            else -> throw IllegalArgumentException("Unknown operator")
                        }
                        push(r)
                    }
                }

                is Token.Func -> push(applyFunction(t.name, pop()))

                is Token.Postfix -> {
                    val a = pop()
                    val r = when (t.symbol) {
                        "!" -> factorial(a)
                        "%" -> a / 100.0
                        else -> throw IllegalArgumentException("Unknown postfix")
                    }
                    push(r)
                }

                else -> throw IllegalStateException("Unexpected token")
            }
        }
        if (stack.size != 1) throw IllegalArgumentException("Invalid expression")
        val result = stack.first()
        if (result.isNaN()) throw ArithmeticException("Math error")
        return result
    }

    // ---------------------------------------------------------------- Helpers

    private fun applyFunction(name: String, x: Double): Double {
        if (x.isNaN()) throw ArithmeticException("Math error")
        return when (name) {
            "sin"  -> sin(toRadians(x))
            "cos"  -> cos(toRadians(x))
            "tan"  -> tan(toRadians(x))
            "asin" -> {
                if (x < -1.0 || x > 1.0) throw ArithmeticException("asin domain")
                toDegrees(asin(x))
            }
            "acos" -> {
                if (x < -1.0 || x > 1.0) throw ArithmeticException("acos domain")
                toDegrees(acos(x))
            }
            "atan" -> toDegrees(atan(x))
            "ln"   -> {
                if (x <= 0.0) throw ArithmeticException("ln domain")
                ln(x)
            }
            "log"  -> {
                if (x <= 0.0) throw ArithmeticException("log domain")
                log10(x)
            }
            "sqrt" -> {
                if (x < 0.0) throw ArithmeticException("sqrt of negative")
                sqrt(x)
            }
            "abs"  -> abs(x)
            "exp"  -> {
                val r = exp(x)
                if (r.isInfinite()) throw ArithmeticException("Overflow")
                r
            }
            else -> throw IllegalArgumentException("Unknown function")
        }
    }

    private fun factorial(n: Double): Double {
        if (n.isNaN() || n.isInfinite()) throw IllegalArgumentException("Invalid factorial")
        if (n < 0.0 || n != floor(n)) throw IllegalArgumentException("Factorial requires non-negative integer")
        if (n > 170.0) return Double.POSITIVE_INFINITY
        var r = 1.0
        var i = 2
        val limit = n.toInt()
        while (i <= limit) {
            r *= i
            i++
        }
        return r
    }

    private fun toRadians(x: Double) = if (useDegrees) Math.toRadians(x) else x
    private fun toDegrees(x: Double) = if (useDegrees) Math.toDegrees(x) else x
}