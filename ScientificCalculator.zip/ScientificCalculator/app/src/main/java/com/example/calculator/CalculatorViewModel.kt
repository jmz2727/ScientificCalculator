package com.example.calculator

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.Locale
import kotlin.math.abs

/**
 * Typed error category. Language-agnostic so the ViewModel has no Android
 * Context dependency (proper MVVM). The UI maps each value to a localized
 * string via [com.example.calculator.R.string].
 */
enum class CalcError {
    INVALID_EXPRESSION,
    MATH_ERROR
}

data class CalculatorUiState(
    val expression: String = "",
    val isScientific: Boolean = false,   // basic calculator by default
    val useDegrees: Boolean = true,
    val isResult: Boolean = false,
    val error: CalcError? = null
)

sealed interface CalcEvent {
    data class Digit(val value: String) : CalcEvent
    data class Operator(val op: String) : CalcEvent
    data class Function(val name: String) : CalcEvent
    data class Insert(val text: String) : CalcEvent
    data object Decimal : CalcEvent
    data object Clear : CalcEvent
    data object Backspace : CalcEvent
    data object Equals : CalcEvent
    data object ToggleMode : CalcEvent
    data object ToggleAngle : CalcEvent
    data object LParen : CalcEvent
    data object RParen : CalcEvent
    data object SmartParen : CalcEvent
}

class CalculatorViewModel : ViewModel() {

    private val _state = MutableStateFlow(CalculatorUiState())
    val state: StateFlow<CalculatorUiState> = _state.asStateFlow()

    fun onEvent(e: CalcEvent) {
        when (e) {
            is CalcEvent.Digit    -> onDigit(e.value)
            is CalcEvent.Operator -> onOperator(e.op)
            is CalcEvent.Function -> onFunction(e.name)
            is CalcEvent.Insert   -> onInsert(e.text)
            CalcEvent.Decimal     -> onDecimal()
            CalcEvent.Clear       -> _state.update {
                it.copy(expression = "", isResult = false, error = null)
            }
            CalcEvent.Backspace   -> onBackspace()
            CalcEvent.Equals      -> onEquals()
            CalcEvent.ToggleMode  -> _state.update { it.copy(isScientific = !it.isScientific) }
            CalcEvent.ToggleAngle -> _state.update { it.copy(useDegrees = !it.useDegrees) }
            CalcEvent.LParen      -> onInsert("(")
            CalcEvent.RParen      -> onInsert(")")
            CalcEvent.SmartParen  -> onSmartParen()
        }
    }

    // ------------------------------------------------------------------ Input

    private fun onDigit(d: String) = _state.update {
        val base = if (it.isResult) "" else it.expression
        it.copy(expression = base + d, isResult = false, error = null)
    }

    private fun onOperator(op: String) = _state.update {
        val expr = it.expression
        if (expr.isEmpty()) {
            if (op == "-") it.copy(expression = "-", isResult = false, error = null) else it
        } else {
            val last = expr.last()
            val newExpr = when {
                last in "+-×÷^" -> expr.dropLast(1) + op
                last == '(' -> if (op == "-") expr + op else expr
                else -> expr + op
            }
            it.copy(expression = newExpr, isResult = false, error = null)
        }
    }

    private fun onFunction(name: String) = _state.update {
        val expr = if (it.isResult) "$name(${it.expression})" else it.expression + "$name("
        it.copy(expression = expr, isResult = false, error = null)
    }

    private fun onInsert(text: String) = _state.update {
        val base = if (it.isResult) "" else it.expression
        it.copy(expression = base + text, isResult = false, error = null)
    }

    private fun onDecimal() = _state.update {
        val base = if (it.isResult) "" else it.expression
        val tail = base.takeLastWhile { ch -> ch.isDigit() || ch == '.' }
        if ('.' in tail) it
        else it.copy(
            expression = if (tail.isEmpty()) base + "0." else base + ".",
            isResult = false,
            error = null
        )
    }

    private fun onBackspace() = _state.update {
        if (it.isResult) {
            return@update it.copy(expression = "", isResult = false, error = null)
        }
        if (it.expression.isEmpty()) return@update it
        val funcs = listOf(
            "asin(", "acos(", "atan(", "sin(", "cos(", "tan(",
            "log(", "ln(", "sqrt(", "abs(", "exp("
        )
        val matched = funcs.firstOrNull { f -> it.expression.endsWith(f) }
        val newExpr = if (matched != null) it.expression.dropLast(matched.length)
                      else it.expression.dropLast(1)
        it.copy(expression = newExpr, error = null)
    }

    /**
     * Smart parenthesis:
     *  - Insert "(" when the field is empty, ends with "(" or ends with an operator.
     *  - Insert ")" when there is at least one unclosed "(".
     *  - Otherwise (adjacent to a value) insert "(" — implicit multiplication.
     */
    private fun onSmartParen() = _state.update { s ->
        val expr = if (s.isResult) "" else s.expression
        val opens = expr.count { it == '(' }
        val closes = expr.count { it == ')' }
        val last = expr.lastOrNull()

        val insertOpen: Boolean = when {
            expr.isEmpty() -> true
            last == '(' -> true
            last == null -> true
            last in "+-×÷^" -> true
            else -> false
        }

        val addition = when {
            insertOpen -> "("
            opens > closes -> ")"
            else -> "("
        }
        s.copy(expression = expr + addition, isResult = false, error = null)
    }

    // ---------------------------------------------------------------- Evaluate

    private fun onEquals() {
        val s = _state.value
        if (s.expression.isBlank()) return

        val balanced = balanceParentheses(s.expression)

        try {
            val evaluator = ExpressionEvaluator(s.useDegrees)
            val result = evaluator.evaluate(balanced)

            if (!result.isFinite()) {
                _state.value = s.copy(error = CalcError.MATH_ERROR, isResult = false)
                return
            }
            _state.value = s.copy(
                expression = formatNumber(result),
                isResult = true,
                error = null
            )
        } catch (_: ArithmeticException) {
            _state.value = s.copy(error = CalcError.MATH_ERROR, isResult = false)
        } catch (_: Exception) {
            // Never leak a stack trace, exception type, or message to the UI.
            _state.value = s.copy(error = CalcError.INVALID_EXPRESSION, isResult = false)
        }
    }

    private fun balanceParentheses(expression: String): String {
        var opens = 0
        var closes = 0
        for (c in expression) {
            when (c) {
                '(' -> opens++
                ')' -> closes++
            }
        }
        return if (opens > closes) expression + ")".repeat(opens - closes) else expression
    }

    private fun formatNumber(value: Double): String {
        if (value == 0.0) return "0"
        val a = abs(value)
        return when {
            a >= 1e12 || a < 1e-9 -> String.format(Locale.US, "%.6e", value)
            value == value.toLong().toDouble() -> value.toLong().toString()
            else -> {
                val s = String.format(Locale.US, "%.10f", value)
                    .trimEnd('0')
                    .trimEnd('.')
                if (s.isEmpty() || s == "-") "0" else s
            }
        }
    }
}