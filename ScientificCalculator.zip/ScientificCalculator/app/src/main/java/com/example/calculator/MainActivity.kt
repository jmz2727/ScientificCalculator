package com.example.calculator

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CalculatorTheme {
                CalculatorApp()
            }
        }
    }
}

@Composable
fun CalculatorTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun CalculatorApp(vm: CalculatorViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(8.dp)
        ) {
            Toolbar(state, vm::onEvent)
            Display(state, Modifier.weight(1f))
            Keypad(
                state = state,
                onEvent = vm::onEvent,
                modifier = Modifier.weight(if (state.isScientific) 3.6f else 2.6f)
            )
        }
    }
}

/* ------------------------------------------------------------------ Toolbar */

@Composable
private fun Toolbar(state: CalculatorUiState, onEvent: (CalcEvent) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextButton(onClick = { onEvent(CalcEvent.ToggleMode) }) {
            Icon(
                imageVector = if (state.isScientific) Icons.Default.Science
                              else Icons.Default.Calculate,
                contentDescription = stringResource(R.string.cd_toggle_mode)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = stringResource(
                    if (state.isScientific) R.string.mode_scientific
                    else R.string.mode_basic
                )
            )
        }
        if (state.isScientific) {
            TextButton(onClick = { onEvent(CalcEvent.ToggleAngle) }) {
                Text(
                    text = stringResource(
                        if (state.useDegrees) R.string.angle_degrees
                        else R.string.angle_radians
                    ),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/* ------------------------------------------------------------------ Display */

@Composable
private fun Display(state: CalculatorUiState, modifier: Modifier = Modifier) {
    val errorText: String? = state.error?.let { err ->
        stringResource(
            when (err) {
                CalcError.MATH_ERROR -> R.string.error_math
                CalcError.INVALID_EXPRESSION -> R.string.error_invalid
            }
        )
    }
    val displayText = errorText
        ?: state.expression.ifEmpty { stringResource(R.string.zero) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.Bottom
    ) {
        Text(
            text = displayText,
            fontSize = 40.sp,
            fontWeight = FontWeight.Medium,
            color = if (state.error != null) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onBackground,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.End,
            style = LocalTextStyle.current.copy(textDirection = TextDirection.Ltr)
        )
    }
}

/* ---------------------------------------------------------------- Keypad UI */

private enum class Style { Number, Operator, Action, Equals }

private data class Btn(
    val label: String,
    val event: CalcEvent,
    val style: Style = Style.Number,
    val weight: Float = 1f,
    val contentDescRes: Int? = null
)

@Composable
private fun Keypad(
    state: CalculatorUiState,
    onEvent: (CalcEvent) -> Unit,
    modifier: Modifier
) {
    val rows = if (state.isScientific) scientificRows(state.useDegrees) else basicRows
    Column(modifier.fillMaxWidth()) {
        rows.forEach { row ->
            Row(Modifier.fillMaxWidth().weight(1f)) {
                row.forEach { b ->
                    KeyButton(b, onEvent, Modifier.weight(b.weight).fillMaxHeight())
                }
            }
        }
    }
}

@Composable
private fun KeyButton(b: Btn, onEvent: (CalcEvent) -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val (bg, fg) = when (b.style) {
        Style.Number   -> cs.surfaceVariant     to cs.onSurfaceVariant
        Style.Operator -> cs.primaryContainer   to cs.onPrimaryContainer
        Style.Action   -> cs.secondaryContainer to cs.onSecondaryContainer
        Style.Equals   -> cs.primary            to cs.onPrimary
    }
    Surface(
        modifier = modifier.padding(3.dp),
        shape = RoundedCornerShape(18.dp),
        color = bg
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable { onEvent(b.event) }
                .semanticsLabel(b.contentDescRes),
            contentAlignment = Alignment.Center
        ) {
            Text(b.label, color = fg, fontSize = 22.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun Modifier.semanticsLabel(resId: Int?): Modifier {
    if (resId == null) return this
    val label = stringResource(resId)
    return this.then(
        Modifier.semantics { contentDescription = label }
    )
}

/* ------------------------------------------------------------- Layout defs */

private val basicRows: List<List<Btn>> = listOf(
    listOf(
        Btn("C",  CalcEvent.Clear, Style.Action, contentDescRes = R.string.cd_clear),
        Btn("⌫",  CalcEvent.Backspace, Style.Action, contentDescRes = R.string.cd_backspace),
        Btn("%",  CalcEvent.Insert("%"), Style.Operator),
        Btn("÷",  CalcEvent.Operator("÷"), Style.Operator)
    ),
    listOf(
        Btn("7", CalcEvent.Digit("7")),
        Btn("8", CalcEvent.Digit("8")),
        Btn("9", CalcEvent.Digit("9")),
        Btn("×", CalcEvent.Operator("×"), Style.Operator)
    ),
    listOf(
        Btn("4", CalcEvent.Digit("4")),
        Btn("5", CalcEvent.Digit("5")),
        Btn("6", CalcEvent.Digit("6")),
        Btn("−", CalcEvent.Operator("-"), Style.Operator)
    ),
    listOf(
        Btn("1", CalcEvent.Digit("1")),
        Btn("2", CalcEvent.Digit("2")),
        Btn("3", CalcEvent.Digit("3")),
        Btn("+", CalcEvent.Operator("+"), Style.Operator)
    ),
    listOf(
        Btn("( )", CalcEvent.SmartParen, Style.Action,
            contentDescRes = R.string.cd_smart_paren),
        Btn("0", CalcEvent.Digit("0")),
        Btn(".", CalcEvent.Decimal),
        Btn("=", CalcEvent.Equals, Style.Equals,
            contentDescRes = R.string.cd_equals)
    )
)

private fun scientificRows(useDegrees: Boolean): List<List<Btn>> = listOf(
    listOf(
        Btn(if (useDegrees) "DEG" else "RAD", CalcEvent.ToggleAngle, Style.Action,
            contentDescRes = R.string.cd_toggle_angle),
        Btn("(", CalcEvent.LParen, Style.Action),
        Btn(")", CalcEvent.RParen, Style.Action),
        Btn("C", CalcEvent.Clear, Style.Action, contentDescRes = R.string.cd_clear),
        Btn("⌫", CalcEvent.Backspace, Style.Action, contentDescRes = R.string.cd_backspace)
    ),
    listOf(
        Btn("sin", CalcEvent.Function("sin"), Style.Operator),
        Btn("cos", CalcEvent.Function("cos"), Style.Operator),
        Btn("tan", CalcEvent.Function("tan"), Style.Operator),
        Btn("π",   CalcEvent.Insert("π"), Style.Operator),
        Btn("e",   CalcEvent.Insert("e"), Style.Operator)
    ),
    listOf(
        Btn("ln",  CalcEvent.Function("ln"), Style.Operator),
        Btn("log", CalcEvent.Function("log"), Style.Operator),
        Btn("√",   CalcEvent.Insert("√("), Style.Operator),
        Btn("x²",  CalcEvent.Insert("^2"), Style.Operator),
        Btn("xʸ",  CalcEvent.Insert("^"), Style.Operator)
    ),
    listOf(
        Btn("7", CalcEvent.Digit("7")),
        Btn("8", CalcEvent.Digit("8")),
        Btn("9", CalcEvent.Digit("9")),
        Btn("÷", CalcEvent.Operator("÷"), Style.Operator),
        Btn("!", CalcEvent.Insert("!"), Style.Operator)
    ),
    listOf(
        Btn("4", CalcEvent.Digit("4")),
        Btn("5", CalcEvent.Digit("5")),
        Btn("6", CalcEvent.Digit("6")),
        Btn("×", CalcEvent.Operator("×"), Style.Operator),
        Btn("%", CalcEvent.Insert("%"), Style.Operator)
    ),
    listOf(
        Btn("1", CalcEvent.Digit("1")),
        Btn("2", CalcEvent.Digit("2")),
        Btn("3", CalcEvent.Digit("3")),
        Btn("−", CalcEvent.Operator("-"), Style.Operator),
        Btn("+", CalcEvent.Operator("+"), Style.Operator)
    ),
    listOf(
        Btn("0", CalcEvent.Digit("0")),
        Btn(".", CalcEvent.Decimal),
        Btn("=", CalcEvent.Equals, Style.Equals, weight = 3f,
            contentDescRes = R.string.cd_equals)
    )
)