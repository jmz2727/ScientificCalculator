# -----------------------------------------------------------------------------
# Calculator — R8 / ProGuard rules
# -----------------------------------------------------------------------------

# Keep source line numbers for readable crash reports; hide the file name.
-keepattributes SourceFile,LineNumberTable
-renamesourcefileattribute SourceFile

# ---------------- Jetpack Compose ----------------
-keep class androidx.compose.runtime.** { *; }
-keepclassmembers class androidx.compose.runtime.** { *; }
-keep class androidx.compose.ui.** { *; }
-keepclassmembers class androidx.compose.ui.** { *; }
-dontwarn androidx.compose.**

# ---------------- Kotlin metadata ----------------
-keep class kotlin.Metadata { *; }
-keepclassmembers class kotlin.Metadata { public <methods>; }
-keepclassmembers class **$WhenMappings {
    <fields>;
}
-keepattributes RuntimeVisibleAnnotations,AnnotationDefault
-keepattributes InnerClasses,EnclosingMethod

# ---------------- Kotlin Coroutines ----------------
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-keepclassmembers class kotlinx.coroutines.** {
    volatile <fields>;
}
-dontwarn kotlinx.coroutines.**

# ---------------- AndroidX Lifecycle / ViewModel ----------------
-keepclassmembers class * extends androidx.lifecycle.ViewModel {
    <init>(...);
}
-keepclassmembers class * extends androidx.lifecycle.AndroidViewModel {
    <init>(android.app.Application);
}
-keepclassmembers class * implements androidx.lifecycle.LifecycleObserver {
    <init>(...);
}

# ---------------- App-specific ----------------
-keep class com.example.calculator.CalculatorUiState { *; }
-keep class com.example.calculator.CalcError { *; }
-keep class com.example.calculator.CalcEvent { *; }
-keep class com.example.calculator.CalcEvent$* { *; }
-keep class com.example.calculator.CalculatorViewModel { *; }
-keep class com.example.calculator.ExpressionEvaluator { *; }
-keep class com.example.calculator.ExpressionEvaluator$* { *; }

# ---------------- General good practice ----------------
-keepclassmembers enum * {
    public static **[] values();
    public static ** valueOf(java.lang.String);
}
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator *;
}